
# Example prediction script
import pickle
import pandas as pd
import numpy as np
import json

# Load the model
model_path = "/content/predictive_policing/models/gradient_boosting_20250502_214812.pkl"  # Update this path to where your model is saved

# Load model with error handling
try:
    with open(model_path, 'rb') as f:
        model = pickle.load(f)
except Exception as e:
    print(f"Error loading model: {str(e)}")
    exit(1)

# Import preprocessing function
from preprocessing_20250502_214812 import preprocess_for_prediction

def predict_crime(input_data):
    """
    Predict crime for the given input data

    Parameters:
    -----------
    input_data : dict or DataFrame
        Input data with community area and temporal features

    Returns:
    --------
    float
        Predicted crime crime_count value
    """
    try:
        # Preprocess the data
        processed = preprocess_for_prediction(input_data)

        # Make prediction
        prediction = model.predict(processed)

        return float(prediction[0])
    except Exception as e:
        print(f"Error making prediction: {str(e)}")
        return None

# Example usage
if __name__ == "__main__":
    # Example data for a community area in a specific month
    sample_data = {
        'month': 1,
        'year': 2024,
        'community_area': '1',
        # Add values for required features
    }

    result = predict_crime(sample_data)
    if result is not None:
        print(f"Predicted crime_count: {result:.2f}")
    else:
        print("Prediction failed")
