
# Preprocessing code for deployment
import pandas as pd
import numpy as np

def safe_median(s):
    """Safely compute median of a Series, handling NaN values and conversion issues"""
    try:
        median = s.dropna().median()
        if hasattr(median, 'item'):
            return float(median.item())
        else:
            return float(median) if pd.notna(median) else 0.0
    except (TypeError, ValueError):
        return 0.0

def preprocess_for_prediction(raw_data):
    """
    Preprocess raw data for prediction with trained model.

    Parameters:
    -----------
    raw_data : dict or DataFrame
        Raw input data with community area and time features

    Returns:
    --------
    processed_features : DataFrame
        Processed features ready for model prediction
    """
    # Convert to DataFrame if dictionary
    if isinstance(raw_data, dict):
        data = pd.DataFrame([raw_data])
    else:
        data = raw_data.copy()

    # Required features for the model
    required_features = ['month', 'rolling_std_3m', 'month_1', 'month_2', 'month_3', 'month_4', 'month_5', 'month_6', 'month_7', 'month_8', 'month_9', 'month_10', 'month_11', 'month_12', 'quarter_1', 'quarter_2', 'quarter_3', 'quarter_4', 'percent_households_below_poverty', 'percent_aged_25_without_high_school_diploma', 'percent_aged_under_18_or_over_64']

    # Fill missing values
    for feature in required_features:
        if feature not in data.columns:
            data[feature] = 0  # Default value

    # Select and order features
    X = data[required_features]

    # Fill any remaining missing values
    for col in X.columns:
        if X[col].isna().any():
            X[col] = X[col].fillna(safe_median(X[col]) if pd.api.types.is_numeric_dtype(X[col]) else 'UNKNOWN')

    # Apply scaling
    means = [6.5, 30.709114797690212, 0.08333333333333333, 0.08333333333333333, 0.08333333333333333, 0.08333333333333333, 0.08333333333333333, 0.08333333333333333, 0.08333333333333333, 0.08333333333333333, 0.08333333333333333, 0.08333333333333333, 0.08333333333333333, 0.08333333333333333, 0.25, 0.25, 0.25, 0.25, 21.67948717948718, 20.33846153846154, 35.853846153846156]
    stds = [3.452052529534663, 49.228019642425046, 0.27638539919628335, 0.27638539919628335, 0.27638539919628335, 0.27638539919628335, 0.27638539919628335, 0.27638539919628335, 0.27638539919628335, 0.27638539919628335, 0.27638539919628335, 0.27638539919628335, 0.27638539919628335, 0.27638539919628335, 0.4330127018922193, 0.4330127018922193, 0.4330127018922193, 0.4330127018922193, 11.385982823859356, 11.669764029530802, 7.181291439954385]

    # Apply scaling with error handling
    X_scaled = np.zeros(X.shape)
    for i, col in enumerate(X.columns):
        try:
            X_scaled[:, i] = (X[col].values - means[i]) / max(stds[i], 1e-10)  # Avoid division by zero
        except Exception as e:
            print(f"Error scaling column {col}: {str(e)}")
            X_scaled[:, i] = X[col].values  # Use unscaled values as fallback

    X_scaled_df = pd.DataFrame(X_scaled, columns=X.columns, index=X.index)

    return X_scaled_df

# Example usage:
# import pickle
# with open('model.pkl', 'rb') as f:
#     model = pickle.load(f)
#
# sample_data = {
#     'community_area': '1',
#     'month': 1,
#     'year': 2024,
#     # Add other required feature values
# }
#
# processed = preprocess_for_prediction(sample_data)
# prediction = model.predict(processed)
# print(f"Predicted crime_count: {prediction[0]:.2f}")
